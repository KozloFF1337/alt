# Структура базы данных Altair

## Обзор

База данных PostgreSQL `ASTEP_RES` содержит данные о турбинах и котлах для системы мониторинга энергетического оборудования.

## Таблицы

### 1. Turbins (Турбины)

Таблица хранит данные об удельном расходе топлива (УРТ) турбин.

```sql
CREATE TABLE "Turbins" (
    "Id" SERIAL PRIMARY KEY,
    "StationID" INTEGER NOT NULL,
    "TurbinID" TEXT NOT NULL,
    "PeriodType" INTEGER NOT NULL,
    "PeriodValue" INTEGER NOT NULL,
    "URT" DOUBLE PRECISION NOT NULL,
    "Consumption" DOUBLE PRECISION NOT NULL,
    "NominalURT" DOUBLE PRECISION NOT NULL,
    "Date" TIMESTAMP WITH TIME ZONE NULL
);
```

**Поля:**
- `Id` - уникальный идентификатор записи
- `StationID` - идентификатор станции
- `TurbinID` - идентификатор турбины
- `PeriodType` - тип периода (0=День, 1=Месяц, 2=Год)
- `PeriodValue` - значение периода (номер дня/месяца/года)
- `URT` - фактический удельный расход топлива
- `Consumption` - расход топлива
- `NominalURT` - нормативный удельный расход топлива
- `Date` - дата записи (для дневных данных - конкретная дата, для месячных - первый день месяца, для годовых - первый день года)

**Индексы:**
- PRIMARY KEY на `Id`

### 2. Boilers (Котлы)

Таблица хранит данные о КПД котлов.

```sql
CREATE TABLE "Boilers" (
    "Id" SERIAL PRIMARY KEY,
    "StationID" INTEGER NOT NULL,
    "BoilerID" TEXT NOT NULL,
    "PeriodType" INTEGER NOT NULL,
    "PeriodValue" INTEGER NOT NULL,
    "KPD" DOUBLE PRECISION NOT NULL,
    "Production" DOUBLE PRECISION NOT NULL,
    "Consumption" DOUBLE PRECISION NOT NULL,
    "Date" TIMESTAMP WITH TIME ZONE NULL
);
```

**Поля:**
- `Id` - уникальный идентификатор записи
- `StationID` - идентификатор станции
- `BoilerID` - идентификатор котла
- `PeriodType` - тип периода (0=День, 1=Месяц, 2=Год)
- `PeriodValue` - значение периода (номер дня/месяца/года)
- `KPD` - коэффициент полезного действия котла
- `Production` - выработка
- `Consumption` - расход топлива
- `Date` - дата записи (для дневных данных - конкретная дата, для месячных - первый день месяца, для годовых - первый день года)

**Индексы:**
- PRIMARY KEY на `Id`

### 3. HomePages

Таблица хранит агрегированные данные для главной страницы.

## PeriodType (Типы периодов)

Enum `PeriodType` определяет тип периода агрегации данных:

```csharp
public enum PeriodType
{
    Day = 0,    // День
    Month = 1,  // Месяц
    Year = 2    // Год
}
```

## Примеры использования Date

### Дневные записи (PeriodType = 0)
- `Date` содержит конкретную дату, например: `2025-12-18`
- `PeriodValue` может быть номером дня в диапазоне (например, 1-30 для последних 30 дней)

### Месячные записи (PeriodType = 1)
- `Date` содержит первый день месяца, например: `2025-01-01` для января
- `PeriodValue` - номер месяца (1-12)

### Годовые записи (PeriodType = 2)
- `Date` содержит первый день года, например: `2024-01-01`
- `PeriodValue` - год (например, 2024)

## Миграции

### Примененные миграции:
1. `20251212093022_InitialCreate` - создание таблицы Boilers
2. `20251212093041_InitialCreate` - создание таблицы Turbins
3. `20251219195108_AddDateColumnToTurbin` - добавление колонки Date в Turbins
4. `20251219195128_AddDateColumnToBoiler` - добавление колонки Date в Boilers

## Команды для работы с БД

### Создание миграции
```bash
dotnet ef migrations add <MigrationName> --context TurbinDbContext --output-dir Migrations/TurbinDb
dotnet ef migrations add <MigrationName> --context BoilerDbContext --output-dir Migrations
```

### Применение миграций
```bash
dotnet ef database update --context TurbinDbContext
dotnet ef database update --context BoilerDbContext
```

### Добавление тестовых данных
```bash
dotnet run -- --seed-data
```

## Статистика данных

По состоянию на 19.12.2025:

**Turbins:**
- Day: 79 записей (все с датами)
- Month: 113 записей (21 с датами, 92 без дат)
- Year: 131 записей (все с датами)

**Boilers:**
- Day: 99 записей (все с датами)
- Month: 162 записей (27 с датами, 135 без дат)
- Year: 195 записей (все с датами)

## Тестовые данные

В БД добавлены тестовые записи (StationID=999) для проверки функциональности:
- 7 тестовых турбин (TEST-T1 до TEST-T7) с датами за последние 7 дней
- 7 тестовых котлов (TEST-B1 до TEST-B7) с датами за последние 7 дней

## Подключение к БД

**Local (PostgreSQL):**
```
Server=localhost
Port=5432
Database=ASTEP_RES
User Id=FLZK
Password=root
```

**ASTEP (SQL Server):**
```
Server=KMR-S-APP-TEP3.CORP.SUEK.RU
Database=ASTEPSGKID
Trusted_Connection=True
TrustServerCertificate=true
```
