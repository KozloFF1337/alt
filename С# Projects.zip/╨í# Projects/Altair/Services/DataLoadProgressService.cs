using System.Collections.Concurrent;

namespace Altair.Services
{
    public interface IDataLoadProgressService
    {
        DataLoadProgress GetProgress();
        void StartLoading(string taskName, int totalSteps);
        void UpdateProgress(int currentStep, string currentStepName);
        void CompleteLoading(bool success, string message);
        void ResetProgress();
        void RequestCancellation();
        bool IsCancellationRequested { get; }
        CancellationToken CancellationToken { get; }
        bool IsLoading { get; }
    }

    public class DataLoadProgress
    {
        public bool IsLoading { get; set; }
        public string TaskName { get; set; } = string.Empty;
        public int TotalSteps { get; set; }
        public int CurrentStep { get; set; }
        public string CurrentStepName { get; set; } = string.Empty;
        public double ProgressPercent => TotalSteps > 0 ? Math.Round((double)CurrentStep / TotalSteps * 100, 1) : 0;
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public bool IsCompleted { get; set; }
        public bool IsSuccess { get; set; }
        public bool IsCancelled { get; set; }
        public string Message { get; set; } = string.Empty;
        public TimeSpan? ElapsedTime => IsLoading || IsCompleted
            ? (EndTime ?? DateTime.Now) - StartTime
            : null;
    }

    public class DataLoadProgressService : IDataLoadProgressService
    {
        private readonly object _lock = new object();
        private DataLoadProgress _progress = new DataLoadProgress();
        private CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();

        public bool IsLoading => _progress.IsLoading;
        public bool IsCancellationRequested => _cancellationTokenSource.IsCancellationRequested;
        public CancellationToken CancellationToken => _cancellationTokenSource.Token;

        public DataLoadProgress GetProgress()
        {
            lock (_lock)
            {
                return new DataLoadProgress
                {
                    IsLoading = _progress.IsLoading,
                    TaskName = _progress.TaskName,
                    TotalSteps = _progress.TotalSteps,
                    CurrentStep = _progress.CurrentStep,
                    CurrentStepName = _progress.CurrentStepName,
                    StartTime = _progress.StartTime,
                    EndTime = _progress.EndTime,
                    IsCompleted = _progress.IsCompleted,
                    IsSuccess = _progress.IsSuccess,
                    IsCancelled = _progress.IsCancelled,
                    Message = _progress.Message
                };
            }
        }

        public void StartLoading(string taskName, int totalSteps)
        {
            lock (_lock)
            {
                // Создаём новый CancellationTokenSource для каждой загрузки
                _cancellationTokenSource = new CancellationTokenSource();
                _progress = new DataLoadProgress
                {
                    IsLoading = true,
                    TaskName = taskName,
                    TotalSteps = totalSteps,
                    CurrentStep = 0,
                    CurrentStepName = "Инициализация...",
                    StartTime = DateTime.Now,
                    IsCompleted = false,
                    IsSuccess = false,
                    IsCancelled = false,
                    Message = string.Empty
                };
            }
        }

        public void RequestCancellation()
        {
            lock (_lock)
            {
                if (_progress.IsLoading && !_cancellationTokenSource.IsCancellationRequested)
                {
                    _cancellationTokenSource.Cancel();
                    _progress.CurrentStepName = "Отмена загрузки...";
                }
            }
        }

        public void UpdateProgress(int currentStep, string currentStepName)
        {
            lock (_lock)
            {
                _progress.CurrentStep = currentStep;
                _progress.CurrentStepName = currentStepName;
            }
        }

        public void CompleteLoading(bool success, string message)
        {
            lock (_lock)
            {
                _progress.IsLoading = false;
                _progress.IsCompleted = true;
                _progress.IsSuccess = success;
                _progress.Message = message;
                _progress.EndTime = DateTime.Now;
                _progress.CurrentStep = _progress.TotalSteps;
                _progress.CurrentStepName = success ? "Завершено" : "Ошибка";
            }
        }

        public void ResetProgress()
        {
            lock (_lock)
            {
                _progress = new DataLoadProgress();
            }
        }
    }
}
