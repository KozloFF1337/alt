using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using ClosedXML.Excel;
using Altair.Models;

namespace Altair.Services
{
    public static class Akscodes
{
    // Словари для хранения данных котлов и турбин
    public static Dictionary<int, List<string>> matching_dict_KA { get; private set; } = new Dictionary<int, List<string>>();
    public static Dictionary<int, List<string>> matching_dict_TA { get; private set; } = new Dictionary<int, List<string>>();

    // Дополнительные поля
    public static BoilerRecord rec_KA = new BoilerRecord();
    public static TurbinRecord rec_TA = new TurbinRecord();
    public static Turbin rec_WT = new Turbin();
    public static Boiler rec_WB = new Boiler();
    public static List<Turbin> weekTurbins = new List<Turbin>();
    public static List<Boiler> weekBoilers = new List<Boiler>();

    // Базовый путь к папке Services/config (устанавливается при инициализации)
    private static string _configBasePath = "";

    /// <summary>
    /// Инициализирует базовый путь для конфигурационных файлов
    /// </summary>
    public static void Initialize(string contentRootPath)
    {
        _configBasePath = Path.Combine(contentRootPath, "Services", "config");
        LoadFromExcel();
    }

    // Статический конструктор - пустой, загрузка происходит через Initialize
    static Akscodes()
    {
        // Загрузка происходит через Initialize()
    }

    /// <summary>
    /// Загружает данные из Excel файла config/config.xlsx
    /// </summary>
    private static void LoadFromExcel()
    {
        // Если путь не инициализирован, пробуем определить автоматически
        if (string.IsNullOrEmpty(_configBasePath))
        {
            // Пробуем найти путь относительно текущей директории
            string currentDir = Directory.GetCurrentDirectory();
            _configBasePath = Path.Combine(currentDir, "Services", "config");
        }

        string configPath = Path.Combine(_configBasePath, "config.xlsx");

        if (!File.Exists(configPath))
        {
            Console.WriteLine($"[Akscodes] Файл конфигурации не найден: {configPath}");
            return;
        }

        try
        {
            using (var workbook = new XLWorkbook(configPath))
            {
                foreach (var worksheet in workbook.Worksheets)
                {
                    // Пропускаем лист инструкции
                    if (worksheet.Name == "Инструкция")
                        continue;

                    // Извлекаем код станции из названия листа (первые 2 символа)
                    string sheetName = worksheet.Name;
                    if (sheetName.Length < 2)
                        continue;

                    if (!int.TryParse(sheetName.Substring(0, 2), out int stationCode))
                        continue;

                    // Парсим данные листа
                    var boilerRows = new List<string>();
                    var turbineRows = new List<string>();

                    bool inBoilers = false;
                    bool inTurbines = false;
                    int headerRow = 0;

                    int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;

                    for (int row = 1; row <= lastRow; row++)
                    {
                        string cellA = GetCellValue(worksheet, row, 1);

                        if (cellA == "КОТЛЫ")
                        {
                            inBoilers = true;
                            inTurbines = false;
                            headerRow = row + 1;
                            continue;
                        }

                        if (cellA == "ТУРБИНЫ")
                        {
                            inBoilers = false;
                            inTurbines = true;
                            headerRow = row + 1;
                            continue;
                        }

                        // Пропускаем заголовки и пустые строки
                        if (row == headerRow || string.IsNullOrWhiteSpace(cellA) || cellA.Contains("(код:"))
                            continue;

                        if (inBoilers)
                        {
                            // Читаем 9 параметров котла (колонки B-J)
                            var values = new List<string>();
                            for (int col = 2; col <= 10; col++)
                            {
                                values.Add(GetCellValue(worksheet, row, col));
                            }

                            if (values.Count > 0 && !string.IsNullOrWhiteSpace(values[0]))
                            {
                                boilerRows.Add("'" + string.Join(",", values) + "'");
                            }
                        }
                        else if (inTurbines)
                        {
                            // Читаем 5 параметров турбины (колонки B-F)
                            var values = new List<string>();
                            for (int col = 2; col <= 6; col++)
                            {
                                values.Add(GetCellValue(worksheet, row, col));
                            }

                            // Убираем пустые значения в конце
                            while (values.Count > 0 && string.IsNullOrWhiteSpace(values[values.Count - 1]))
                                values.RemoveAt(values.Count - 1);

                            if (values.Count > 0 && !string.IsNullOrWhiteSpace(values[0]))
                            {
                                turbineRows.Add("'" + string.Join(",", values) + "'");
                            }
                        }
                    }

                    // Добавляем данные в словари
                    if (boilerRows.Count > 0)
                    {
                        matching_dict_KA[stationCode] = boilerRows;
                    }

                    if (turbineRows.Count > 0)
                    {
                        matching_dict_TA[stationCode] = turbineRows;
                    }
                }
            }

            Console.WriteLine($"[Akscodes] Загружено станций КА: {matching_dict_KA.Count}, ТА: {matching_dict_TA.Count}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Akscodes] Ошибка загрузки конфигурации: {ex.Message}");
        }
    }

    /// <summary>
    /// Перезагружает данные из Excel файла
    /// </summary>
    public static void Reload()
    {
        matching_dict_KA.Clear();
        matching_dict_TA.Clear();
        LoadFromExcel();
    }

    /// <summary>
    /// Возвращает путь к папке конфигурации
    /// </summary>
    public static string GetConfigPath() => _configBasePath;

    /// <summary>
    /// Получает список кодов котлов для станции
    /// </summary>
    public static List<string> GetBoilerCodes(int stationCode)
    {
        return matching_dict_KA.TryGetValue(stationCode, out var codes) ? codes : new List<string>();
    }

    /// <summary>
    /// Получает список кодов турбин для станции
    /// </summary>
    public static List<string> GetTurbineCodes(int stationCode)
    {
        return matching_dict_TA.TryGetValue(stationCode, out var codes) ? codes : new List<string>();
    }

    private static string GetCellValue(IXLWorksheet worksheet, int row, int col)
    {
        var cell = worksheet.Cell(row, col);
        if (cell == null || cell.IsEmpty())
            return "";

        var value = cell.Value;
        if (value.IsBlank)
            return "";

        return value.ToString()?.Trim() ?? "";
    }
}
}
