using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public class DataService : IDataService
{
    private readonly IBoilerRepository _boilerRepository;
    private readonly ITurbinRepository _turbinRepository;
    private readonly IHomePageRepository _homePageRepository;

    public DataService(IBoilerRepository boilerRepository, ITurbinRepository turbinRepository, IHomePageRepository homePageRepository)
    {
        _boilerRepository = boilerRepository;
        _turbinRepository = turbinRepository;
        _homePageRepository = homePageRepository;
    }

    public async Task<List<Boiler>> GetBoilers(PeriodType periodType)
    {
        return await _boilerRepository.GetBoilers(periodType);
    }

    public async Task<List<Turbin>> GetTurbins(PeriodType periodType)
    {
        return await _turbinRepository.GetTurbins(periodType);
    }

    public async Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date)
    {
        return await _boilerRepository.GetBoilersByDate(periodType, date);
    }

    public async Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date)
    {
        return await _turbinRepository.GetTurbinsByDate(periodType, date);
    }

    public async Task<List<DateTime>> GetAvailableDays()
    {
        // Берём даты из турбин (они должны совпадать с котлами)
        return await _turbinRepository.GetAvailableDates(PeriodType.Day);
    }

    public async Task<List<DateTime>> GetAvailableMonths()
    {
        return await _turbinRepository.GetAvailableDates(PeriodType.Month);
    }

    public async Task<List<int>> GetAvailableYears()
    {
        var dates = await _turbinRepository.GetAvailableDates(PeriodType.Year);
        return dates.Select(d => d.Year).Distinct().OrderByDescending(y => y).ToList();
    }

    public async Task<HomePage> GetHomePageData()
    {
        var homePages = await _homePageRepository.Get();
        return homePages?.Count > 0 ? homePages[0] : null!;
    }
}
