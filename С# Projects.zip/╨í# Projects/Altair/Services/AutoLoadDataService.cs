using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Altair.Services
{
    public class AutoLoadDataService : IHostedService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<AutoLoadDataService> _logger;

        public AutoLoadDataService(IServiceProvider serviceProvider, ILogger<AutoLoadDataService> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Автозагрузка данных из АСТЭП при старте приложения...");

            try
            {
                // Запускаем загрузку в фоновом режиме
                _ = Task.Run(async () =>
                {
                    try
                    {
                        // Создаем scope для получения scoped сервисов
                        using var scope = _serviceProvider.CreateScope();
                        var dbLoadService = scope.ServiceProvider.GetRequiredService<IDBLoadService>();

                        _logger.LogInformation("Запуск полной загрузки данных из АСТЭП...");

                        // Выполняем полную загрузку данных из АСТЭП
                        await dbLoadService.ExecuteFullLoadAsync();

                        _logger.LogInformation("Автозагрузка данных из АСТЭП завершена успешно");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при автозагрузке данных из АСТЭП");
                    }
                }, cancellationToken);

                _logger.LogInformation("Автозагрузка данных запущена в фоновом режиме");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Не удалось запустить автозагрузку данных");
            }

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Остановка сервиса автозагрузки данных");
            return Task.CompletedTask;
        }
    }
}
