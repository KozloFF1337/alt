using Microsoft.Data.SqlClient;
using Altair.Models;
using Npgsql;
using System.Diagnostics;
using System.Globalization;

public static class DBFunctions
{
    /// <summary>
    /// Преобразует число в двухзначную строку (добавляет ведущий ноль)
    /// </summary>
    public static string Correct(int x)
    {
        if (x < 10)
            return "0" + x;
        else
            return x.ToString();
    }

    /// <summary>
    /// Функция безопасной конвертации двойных значений
    /// </summary>
    private static double TryParseDouble(object value)
    {
        if (value is DBNull || string.IsNullOrWhiteSpace(value?.ToString()))
            return 0;

        string normalizedValue = value.ToString()!.Trim().Replace(',', '.');

        if (!double.TryParse(normalizedValue, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out var result))
            return 0;

        return Math.Round(result, 3);
    }

    /// <summary>
    /// Загрузка сырых данных котлов из АСТЭП (устаревший метод, оставлен для обратной совместимости)
    /// </summary>
    public static void GenerateDB_KA(BoilerRecord rec_KA, Dictionary<int, List<string>> matching_dict_KA, string insertQuerry_KA, string format, NpgsqlConnection connection1, SqlConnection connection)
    {
        foreach (var dic in matching_dict_KA)
        {
            foreach (string code in dic.Value)
            {
                string sql_start = $"exec dbo.p_GetParamValuePivot '{Correct(dic.Key)}','Основная', ";
                string sql_end = ", '2025-01-01 00:00:00',  '2025-12-31 23:00:00',  'Сутки';";

                rec_KA.StationID = short.Parse(code.Substring(11, 2));
                rec_KA.BoilerID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                rec_KA.BoilerID = rec_KA.BoilerID.Replace("A", "А").Replace("B", "Б");

                string a = sql_start + code + sql_end;
                SqlCommand command = new SqlCommand(a, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    try
                    {
                        rec_KA.Date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), format, CultureInfo.InvariantCulture);
                        rec_KA.Consumption = TryParseDouble(reader[1]);
                        rec_KA.KPD = TryParseDouble(reader[2]);
                        rec_KA.Production = TryParseDouble(reader[3]);
                        rec_KA.Hours = int.TryParse(reader[4]?.ToString(), out var hours) ? hours : 0;
                        rec_KA.humidity = TryParseDouble(reader[5]);
                        rec_KA.ash = TryParseDouble(reader[6]);
                        rec_KA.temp_fact = TryParseDouble(reader[7]);
                        rec_KA.temp_nominal = TryParseDouble(reader[8]);
                        rec_KA.temp_koef = TryParseDouble(reader[9]);

                        using (var insertCommand = new NpgsqlCommand(insertQuerry_KA, connection1))
                        {
                            insertCommand.Parameters.AddWithValue("@BoilerID", rec_KA.BoilerID);
                            insertCommand.Parameters.AddWithValue("@StationID", rec_KA.StationID);
                            insertCommand.Parameters.AddWithValue("@Production", rec_KA.Production);
                            insertCommand.Parameters.AddWithValue("@KPD", rec_KA.KPD);
                            insertCommand.Parameters.AddWithValue("@Date", rec_KA.Date);
                            insertCommand.Parameters.AddWithValue("@Consumption", rec_KA.Consumption);
                            insertCommand.Parameters.AddWithValue("@Hours", rec_KA.Hours);
                            insertCommand.Parameters.AddWithValue("@Temp_fact", rec_KA.temp_fact);
                            insertCommand.Parameters.AddWithValue("@Temp_nominal", rec_KA.temp_nominal);
                            insertCommand.Parameters.AddWithValue("@Temp_koef", rec_KA.temp_koef);
                            insertCommand.Parameters.AddWithValue("@Humidity", rec_KA.humidity);
                            insertCommand.Parameters.AddWithValue("@Ash", rec_KA.ash);

                            insertCommand.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка при обработке строки: {ex.Message}");
                    }
                }
                reader.Close();
            }
        }
    }

    /// <summary>
    /// Загрузка сырых данных турбин из АСТЭП (устаревший метод, оставлен для обратной совместимости)
    /// </summary>
    public static void GenerateDB_TA(TurbinRecord rec_TA, Dictionary<int, List<string>> matching_dict_TA, string insertQuerry_TA, string format, NpgsqlConnection connection1, SqlConnection connection)
    {
        foreach (var dic in matching_dict_TA)
        {
            foreach (string code in dic.Value)
            {
                string sql_start = $"exec dbo.p_GetParamValuePivot '{Correct(dic.Key)}','Основная', ";
                string sql_end = ", '2025-01-01 00:00:00',  '2025-12-31 23:00:00',  'Сутки';";

                rec_TA.StationID = short.Parse(code.Substring(11, 2));
                rec_TA.TurbinID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                rec_TA.TurbinID = rec_TA.TurbinID.Replace("A", "А").Replace("B", "Б");

                string a = sql_start + code + sql_end;
                SqlCommand command = new SqlCommand(a, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    try
                    {
                        rec_TA.Date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), format, CultureInfo.InvariantCulture);
                        rec_TA.URT = TryParseDouble(reader[1]);
                        rec_TA.Consumption = TryParseDouble(reader[2]);
                        rec_TA.Hours = int.TryParse(reader[3]?.ToString(), out var hours) ? hours : 0;
                        rec_TA.variation = TryParseDouble(reader[4]);

                        if (reader.FieldCount > 5)
                        {
                            rec_TA.NominalURT = TryParseDouble(reader[5]);
                        }
                        else
                        {
                            rec_TA.NominalURT = 0;
                        }

                        using (var insertCommand = new NpgsqlCommand(insertQuerry_TA, connection1))
                        {
                            insertCommand.Parameters.AddWithValue("@TurbinID", rec_TA.TurbinID);
                            insertCommand.Parameters.AddWithValue("@StationID", rec_TA.StationID);
                            insertCommand.Parameters.AddWithValue("@URT", rec_TA.URT);
                            insertCommand.Parameters.AddWithValue("@Date", rec_TA.Date);
                            insertCommand.Parameters.AddWithValue("@Consumption", rec_TA.Consumption);
                            insertCommand.Parameters.AddWithValue("@Hours", rec_TA.Hours);
                            insertCommand.Parameters.AddWithValue("@Variation", rec_TA.variation);
                            insertCommand.Parameters.AddWithValue("@NominalURT", rec_TA.NominalURT);

                            insertCommand.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка при обработке строки: {ex.Message}");
                    }
                }
                reader.Close();
            }
        }
    }
}
