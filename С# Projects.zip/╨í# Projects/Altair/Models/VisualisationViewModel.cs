using System.Collections.Generic;
using Altair.Models;

namespace Altair.Models
{
    // ViewModel для страницы визуализации
    public class VisualisationViewModel
    {
        public List<Boiler> Boilers { get; set; } = new();
        public List<Turbin> Turbins { get; set; } = new();
        public PeriodType SelectedPeriod { get; set; } = PeriodType.Day;
        public DateTime? SelectedDate { get; set; }
        public string? ChartTitle { get; set; }
    }
}
