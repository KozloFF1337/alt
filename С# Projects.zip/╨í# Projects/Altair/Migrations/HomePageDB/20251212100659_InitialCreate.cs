﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Altair.Migrations.HomePageDB
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "HomePages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    year = table.Column<int>(type: "integer", nullable: false),
                    boilers_total = table.Column<double>(type: "double precision", nullable: false),
                    turbins_total = table.Column<double>(type: "double precision", nullable: false),
                    reservs_total_rub = table.Column<double>(type: "double precision", nullable: false),
                    reservs_total_tut = table.Column<double>(type: "double precision", nullable: false),
                    boilers_prisosi = table.Column<double>(type: "double precision", nullable: false),
                    boilers_nedozhogi = table.Column<double>(type: "double precision", nullable: false),
                    boilers_rs = table.Column<double>(type: "double precision", nullable: false),
                    boilers_temp = table.Column<double>(type: "double precision", nullable: false),
                    boilers_consumption = table.Column<double>(type: "double precision", nullable: false),
                    turbins_vac = table.Column<double>(type: "double precision", nullable: false),
                    turbins_rezhim = table.Column<double>(type: "double precision", nullable: false),
                    turbins_temp_pv = table.Column<double>(type: "double precision", nullable: false),
                    turbins_steam_temp = table.Column<double>(type: "double precision", nullable: false),
                    turbins_steam_pressure = table.Column<double>(type: "double precision", nullable: false),
                    turbins_steam_after_pp = table.Column<double>(type: "double precision", nullable: false),
                    turbins_steam_in_reg = table.Column<double>(type: "double precision", nullable: false),
                    turbins_neplan = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_1 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_2 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_3 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_4 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_5 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_6 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_7 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_8 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_9 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_10 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_11 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_12 = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_1_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_2_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_3_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_4_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_5_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_6_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_7_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_8_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_9_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_10_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_11_rub = table.Column<double>(type: "double precision", nullable: false),
                    boilers_final_12_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_1 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_2 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_3 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_4 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_5 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_6 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_7 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_8 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_9 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_10 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_11 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_12 = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_1_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_2_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_3_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_4_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_5_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_6_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_7_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_8_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_9_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_10_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_11_rub = table.Column<double>(type: "double precision", nullable: false),
                    turbins_final_12_rub = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HomePages", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "HomePages");
        }
    }
}
