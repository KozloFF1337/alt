using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

using Altair.Data;
public class BoilerRepository : IBoilerRepository
{
    private readonly BoilerDbContext _context;
    public BoilerRepository(BoilerDbContext context)
    {
        _context = context;
    }

    public async Task<List<Boiler>> GetBoilers(PeriodType periodType)
    {
        // Возвращаем данные с максимальной датой для данного типа периода
        // Фильтруем по PeriodValue > 0 (hours > 0)
        var maxDate = await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType && b.Date != null && b.PeriodValue > 0)
            .MaxAsync(b => (DateTime?)b.Date);

        if (maxDate == null)
        {
            return new List<Boiler>();
        }

        // Сравниваем даты напрямую (без разбивки на части) - как есть в БД
        return await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType
                && b.Date != null
                && b.Date == maxDate
                && b.PeriodValue > 0)
            .ToListAsync();
    }

    public async Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date)
    {
        // Ищем записи с датой, которая совпадает с началом дня переданной даты
        // Нормализуем дату к началу дня без времени
        var dateOnly = date.Date;

        // Сравниваем даты напрямую - ищем записи где дата = переданной дате
        return await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType
                && b.Date != null
                && b.Date.Value.Date == dateOnly
                && b.PeriodValue > 0)
            .ToListAsync();
    }

    public async Task<List<DateTime>> GetAvailableDates(PeriodType periodType)
    {
        // Получаем все уникальные даты для данного периода
        // Нормализуем к дате без времени чтобы избежать дубликатов из-за часовых поясов
        var dates = await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType && b.Date != null && b.PeriodValue > 0)
            .Select(b => b.Date!.Value.Date)
            .Distinct()
            .OrderByDescending(d => d)
            .ToListAsync();

        return dates;
    }
}