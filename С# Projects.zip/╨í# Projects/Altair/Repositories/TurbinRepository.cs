using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

using Altair.Data;
public class TurbinRepository : ITurbinRepository
{
    private readonly TurbinDbContext _context;
    public TurbinRepository(TurbinDbContext context)
    {
        _context = context;
    }

    public async Task<List<Turbin>> GetTurbins(PeriodType periodType)
    {
        // Возвращаем данные с максимальной датой для данного типа периода
        // Фильтруем по PeriodValue > 0 (hours > 0)
        var maxDate = await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date != null && t.PeriodValue > 0)
            .MaxAsync(t => (DateTime?)t.Date);

        if (maxDate == null)
        {
            return new List<Turbin>();
        }

        // Сравниваем даты напрямую (без разбивки на части) - как есть в БД
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType
                && t.Date != null
                && t.Date == maxDate
                && t.PeriodValue > 0)
            .ToListAsync();
    }

    public async Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date)
    {
        // Ищем записи с датой, которая совпадает с началом дня переданной даты
        // Нормализуем дату к началу дня без времени
        var dateOnly = date.Date;

        // Сравниваем даты напрямую - ищем записи где дата = переданной дате
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType
                && t.Date != null
                && t.Date.Value.Date == dateOnly
                && t.PeriodValue > 0)
            .ToListAsync();
    }

    public async Task<List<DateTime>> GetAvailableDates(PeriodType periodType)
    {
        // Получаем все уникальные даты для данного периода
        // Нормализуем к дате без времени чтобы избежать дубликатов из-за часовых поясов
        var dates = await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date != null && t.PeriodValue > 0)
            .Select(t => t.Date!.Value.Date)
            .Distinct()
            .OrderByDescending(d => d)
            .ToListAsync();

        return dates;
    }
}

