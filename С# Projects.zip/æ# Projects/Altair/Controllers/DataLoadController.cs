using Microsoft.AspNetCore.Mvc;
using Altair.Services;

namespace Altair.Controllers
{
    public class DataLoadController : Controller
    {
        private readonly IDBLoadService _dbLoadService;
        private readonly IDataLoadProgressService _progressService;
        private readonly ILogger<DataLoadController> _logger;

        public DataLoadController(IDBLoadService dbLoadService, IDataLoadProgressService progressService, ILogger<DataLoadController> logger)
        {
            _dbLoadService = dbLoadService;
            _progressService = progressService;
            _logger = logger;
        }

        [HttpPost]
        public async Task<IActionResult> LoadData()
        {
            try
            {
                _logger.LogInformation("Пользователь инициировал загрузку данных");
                var result = await _dbLoadService.ExecuteFullLoadAsync();
                return Json(new { success = true, message = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке данных");
                return Json(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> LoadDataWithPeriod([FromBody] LoadPeriodRequest request)
        {
            try
            {
                if (request == null || request.StartDate == default || request.EndDate == default)
                {
                    return Json(new { success = false, message = "Некорректные параметры периода" });
                }

                if (request.StartDate > request.EndDate)
                {
                    return Json(new { success = false, message = "Дата начала не может быть больше даты окончания" });
                }

                _logger.LogInformation($"Пользователь инициировал загрузку данных за период {request.StartDate:dd.MM.yyyy} - {request.EndDate:dd.MM.yyyy}");

                // Запускаем загрузку асинхронно и сразу возвращаем ответ
                Task.Run(async () =>
                {
                    try
                    {
                        await _dbLoadService.ExecuteLoadWithPeriodAsync(request.StartDate, request.EndDate);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Ошибка при фоновой загрузке данных");
                    }
                });

                return Json(new { success = true, message = "Загрузка данных запущена. Следите за прогрессом в индикаторе." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке данных");
                return Json(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }

        [HttpGet]
        public IActionResult GetProgress()
        {
            var progress = _progressService.GetProgress();
            return Json(new
            {
                isLoading = progress.IsLoading,
                taskName = progress.TaskName,
                totalSteps = progress.TotalSteps,
                currentStep = progress.CurrentStep,
                currentStepName = progress.CurrentStepName,
                progressPercent = progress.ProgressPercent,
                isCompleted = progress.IsCompleted,
                isSuccess = progress.IsSuccess,
                message = progress.Message,
                elapsedSeconds = progress.ElapsedTime?.TotalSeconds ?? 0
            });
        }

        [HttpPost]
        public IActionResult ResetProgress()
        {
            _progressService.ResetProgress();
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> LoadBoilers()
        {
            try
            {
                _logger.LogInformation("Загрузка котлов");
                var result = await _dbLoadService.LoadBoilersAsync();
                return Json(new { success = true, message = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке котлов");
                return Json(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> LoadTurbines()
        {
            try
            {
                _logger.LogInformation("Загрузка турбин");
                var result = await _dbLoadService.LoadTurbinesAsync();
                return Json(new { success = true, message = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке турбин");
                return Json(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }
    }

    public class LoadPeriodRequest
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
