using Microsoft.AspNetCore.Mvc;
using Altair.Services;

namespace Altair.Controllers
{
    public class NormativeController : Controller
    {
        private readonly ILogger<NormativeController> _logger;

        public NormativeController(ILogger<NormativeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Download()
        {
            try
            {
                string configPath = GetNormativeConfigPath();

                // Если файл не существует, создаём шаблон
                if (!System.IO.File.Exists(configPath))
                {
                    NormativeValues.CreateTemplateIfNotExists();
                }

                if (!System.IO.File.Exists(configPath))
                {
                    _logger.LogError($"Файл нормативных значений не найден: {configPath}");
                    return NotFound("Файл нормативных значений не найден");
                }

                var fileBytes = System.IO.File.ReadAllBytes(configPath);
                var fileName = $"normative_config_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

                _logger.LogInformation("Пользователь скачал файл нормативных значений");
                return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при скачивании файла нормативных значений");
                return StatusCode(500, "Ошибка при скачивании файла");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return Json(new { success = false, message = "Файл не выбран" });
                }

                if (!file.FileName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    return Json(new { success = false, message = "Допускаются только файлы формата .xlsx" });
                }

                // Сохраняем временный файл для валидации
                var tempPath = Path.GetTempFileName() + ".xlsx";
                try
                {
                    using (var stream = new FileStream(tempPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Валидация файла
                    var validationResult = ValidateNormativeFile(tempPath);
                    if (!validationResult.IsValid)
                    {
                        return Json(new { success = false, message = validationResult.ErrorMessage });
                    }

                    // Если валидация прошла успешно, копируем файл в рабочую директорию
                    string configPath = GetNormativeConfigPath();

                    // Создаём директорию если не существует
                    string? configDir = Path.GetDirectoryName(configPath);
                    if (configDir != null && !Directory.Exists(configDir))
                    {
                        Directory.CreateDirectory(configDir);
                    }

                    // Создаём резервную копию текущего файла
                    if (System.IO.File.Exists(configPath))
                    {
                        var backupPath = configPath.Replace(".xlsx", $"_backup_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");
                        System.IO.File.Copy(configPath, backupPath, true);
                        _logger.LogInformation($"Создана резервная копия: {backupPath}");
                    }

                    // Копируем новый файл
                    System.IO.File.Copy(tempPath, configPath, true);
                    _logger.LogInformation($"Загружен новый файл нормативных значений: {file.FileName}");

                    // Перезагружаем конфигурацию
                    NormativeValues.Reload();
                    _logger.LogInformation("Нормативные значения перезагружены");

                    return Json(new {
                        success = true,
                        message = $"Файл нормативных значений успешно загружен. Загружено станций КПД: {NormativeValues.KpdValues.Count}, УРТ: {NormativeValues.UrtValues.Count}. Все пользователи теперь видят обновлённые нормативы."
                    });
                }
                finally
                {
                    // Удаляем временный файл
                    if (System.IO.File.Exists(tempPath))
                    {
                        System.IO.File.Delete(tempPath);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке файла нормативных значений");
                return Json(new { success = false, message = $"Ошибка при загрузке файла: {ex.Message}" });
            }
        }

        /// <summary>
        /// Получает нормативные значения КПД и УРТ в формате JSON
        /// </summary>
        [HttpGet]
        public IActionResult GetValues()
        {
            try
            {
                return Json(new
                {
                    success = true,
                    kpdValues = NormativeValues.KpdValues,
                    urtValues = NormativeValues.UrtValues
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении нормативных значений");
                return Json(new { success = false, message = ex.Message });
            }
        }

        private string GetNormativeConfigPath()
        {
            // Используем путь из NormativeValues, который был инициализирован с ContentRootPath
            return Path.Combine(NormativeValues.GetConfigPath(), "normative_config.xlsx");
        }

        private NormativeValidationResult ValidateNormativeFile(string filePath)
        {
            try
            {
                using (var workbook = new ClosedXML.Excel.XLWorkbook(filePath))
                {
                    int validSheets = 0;
                    int totalKpd = 0;
                    int totalUrt = 0;

                    foreach (var worksheet in workbook.Worksheets)
                    {
                        // Пропускаем лист инструкции
                        if (worksheet.Name == "Инструкция")
                            continue;

                        // Проверяем, что название листа начинается с двух цифр
                        string sheetName = worksheet.Name;
                        if (sheetName.Length < 2)
                            continue;

                        if (!int.TryParse(sheetName.Substring(0, 2), out int stationCode))
                            continue;

                        // Ищем секции КПД и УРТ
                        bool hasKpd = false;
                        bool hasUrt = false;

                        int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;
                        for (int row = 1; row <= lastRow; row++)
                        {
                            string cellA = worksheet.Cell(row, 1).GetString().Trim();

                            if (cellA == "КПД_КОТЛЫ" || cellA == "КПД КОТЛЫ" || cellA == "КОТЛЫ_КПД")
                            {
                                hasKpd = true;
                            }
                            else if (cellA == "УРТ_ТУРБИНЫ" || cellA == "УРТ ТУРБИНЫ" || cellA == "ТУРБИНЫ_УРТ")
                            {
                                hasUrt = true;
                            }
                        }

                        if (hasKpd) totalKpd++;
                        if (hasUrt) totalUrt++;

                        if (hasKpd || hasUrt)
                            validSheets++;
                    }

                    if (validSheets == 0)
                    {
                        return new NormativeValidationResult
                        {
                            IsValid = false,
                            ErrorMessage = "Файл не содержит валидных листов с нормативными значениями. Убедитесь, что названия листов начинаются с двузначного кода станции и содержат секции КПД_КОТЛЫ и/или УРТ_ТУРБИНЫ."
                        };
                    }

                    return new NormativeValidationResult
                    {
                        IsValid = true,
                        ErrorMessage = $"Найдено {validSheets} станций. КПД: {totalKpd}, УРТ: {totalUrt}"
                    };
                }
            }
            catch (Exception ex)
            {
                return new NormativeValidationResult
                {
                    IsValid = false,
                    ErrorMessage = $"Ошибка при чтении файла: {ex.Message}"
                };
            }
        }

        private class NormativeValidationResult
        {
            public bool IsValid { get; set; }
            public string ErrorMessage { get; set; } = "";
        }
    }
}
