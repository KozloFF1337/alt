public static class SQL_config
{
    public static string format = "dd.MM.yyyy";
    public static string connectionStringPGSQL = @"Server=localhost;Port=5432;Database=ASTEP_RES;User Id=postgres;Password=root;";
    public static string connectionString = "Server=KMR-S-APP-TEP3.CORP.SUEK.RU; Database=ASTEPSGKID; Trusted_Connection = True; TrustServerCertificate=true;";

    // ============ RAW DATA (дневные данные из АСТЭП с параметром 'Сутки') ============
    public static string insertQuerry_KA_upsert = @"
    INSERT INTO raw_boilers(BoilerID, stationID, KPD, production, date, consumption, hours, temp_fact, temp_nominal, temp_koef, humidity, ash)
    VALUES(@BoilerID, @StationID, @KPD, @Production, @Date, @Consumption, @Hours, @Temp_fact, @Temp_nominal, @Temp_koef, @Humidity, @Ash)
    ON CONFLICT (BoilerID, stationID, date) DO UPDATE SET
        KPD = EXCLUDED.KPD,
        production = EXCLUDED.production,
        consumption = EXCLUDED.consumption,
        hours = EXCLUDED.hours,
        temp_fact = EXCLUDED.temp_fact,
        temp_nominal = EXCLUDED.temp_nominal,
        temp_koef = EXCLUDED.temp_koef,
        humidity = EXCLUDED.humidity,
        ash = EXCLUDED.ash;";

    public static string insertQuerry_TA_upsert = @"
    INSERT INTO raw_turbins(TurbinID, stationID, URT, consumption, date, hours, variation, nominal_urt)
    VALUES(@TurbinID, @StationID, @URT, @Consumption, @Date, @Hours, @Variation, @NominalURT)
    ON CONFLICT (TurbinID, stationID, date) DO UPDATE SET
        URT = EXCLUDED.URT,
        consumption = EXCLUDED.consumption,
        hours = EXCLUDED.hours,
        variation = EXCLUDED.variation,
        nominal_urt = EXCLUDED.nominal_urt;";

    // ============ RAW MONTHLY DATA (месячные данные из АСТЭП с параметром 'Месяц') ============
    public static string insertQuerry_KA_monthly_upsert = @"
    INSERT INTO raw_boilers_monthly(BoilerID, stationID, KPD, production, month_date, consumption, hours, temp_fact, temp_nominal, temp_koef, humidity, ash)
    VALUES(@BoilerID, @StationID, @KPD, @Production, @Date, @Consumption, @Hours, @Temp_fact, @Temp_nominal, @Temp_koef, @Humidity, @Ash)
    ON CONFLICT (BoilerID, stationID, month_date) DO UPDATE SET
        KPD = EXCLUDED.KPD,
        production = EXCLUDED.production,
        consumption = EXCLUDED.consumption,
        hours = EXCLUDED.hours,
        temp_fact = EXCLUDED.temp_fact,
        temp_nominal = EXCLUDED.temp_nominal,
        temp_koef = EXCLUDED.temp_koef,
        humidity = EXCLUDED.humidity,
        ash = EXCLUDED.ash;";

    public static string insertQuerry_TA_monthly_upsert = @"
    INSERT INTO raw_turbins_monthly(TurbinID, stationID, URT, consumption, month_date, hours, variation, nominal_urt)
    VALUES(@TurbinID, @StationID, @URT, @Consumption, @Date, @Hours, @Variation, @NominalURT)
    ON CONFLICT (TurbinID, stationID, month_date) DO UPDATE SET
        URT = EXCLUDED.URT,
        consumption = EXCLUDED.consumption,
        hours = EXCLUDED.hours,
        variation = EXCLUDED.variation,
        nominal_urt = EXCLUDED.nominal_urt;";

    // ============ PROCESSED DATA (обработанные данные по периодам) ============
    // Эти данные НЕ очищаются (без TRUNCATE), используем UPSERT
    public static string insertQuerry_day_KA = @"
    INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""Date"")
    VALUES (@BoilerID, @StationID, @KPD, @Production, @Consumption, @PeriodType, @PeriodValue, @Date)
    ON CONFLICT (""BoilerID"", ""StationID"", ""PeriodType"", ""Date"") DO UPDATE SET
        ""KPD"" = EXCLUDED.""KPD"",
        ""Production"" = EXCLUDED.""Production"",
        ""Consumption"" = EXCLUDED.""Consumption"",
        ""PeriodValue"" = EXCLUDED.""PeriodValue"";";

    public static string insertQuerry_day_TA = @"
    INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""NominalURT"", ""Date"")
    VALUES (@TurbinID, @StationID, @URT, @Consumption, @PeriodType, @PeriodValue, @NominalURT, @Date)
    ON CONFLICT (""TurbinID"", ""StationID"", ""PeriodType"", ""Date"") DO UPDATE SET
        ""URT"" = EXCLUDED.""URT"",
        ""Consumption"" = EXCLUDED.""Consumption"",
        ""PeriodValue"" = EXCLUDED.""PeriodValue"",
        ""NominalURT"" = EXCLUDED.""NominalURT"";";

    // ============ SQL для создания таблиц месячных данных ============
    public static string createMonthlyTablesQuery = @"
    -- Таблица для хранения месячных данных котлов (из АСТЭП с параметром 'Месяц')
    CREATE TABLE IF NOT EXISTS raw_boilers_monthly (
        id SERIAL PRIMARY KEY,
        BoilerID VARCHAR(10) NOT NULL,
        stationID SMALLINT NOT NULL,
        KPD NUMERIC(10, 3),
        production NUMERIC(15, 3),
        month_date DATE NOT NULL,
        consumption NUMERIC(15, 3),
        hours INTEGER,
        temp_fact NUMERIC(10, 3),
        temp_nominal NUMERIC(10, 3),
        temp_koef NUMERIC(10, 5),
        humidity NUMERIC(10, 3),
        ash NUMERIC(10, 3),
        UNIQUE(BoilerID, stationID, month_date)
    );

    -- Таблица для хранения месячных данных турбин (из АСТЭП с параметром 'Месяц')
    CREATE TABLE IF NOT EXISTS raw_turbins_monthly (
        id SERIAL PRIMARY KEY,
        TurbinID VARCHAR(10) NOT NULL,
        stationID SMALLINT NOT NULL,
        URT NUMERIC(10, 3),
        consumption NUMERIC(15, 3),
        month_date DATE NOT NULL,
        hours INTEGER,
        variation NUMERIC(10, 3),
        nominal_urt NUMERIC(10, 3),
        UNIQUE(TurbinID, stationID, month_date)
    );

    -- Добавляем колонку Date в таблицу Boilers если её нет
    ALTER TABLE ""Boilers"" ADD COLUMN IF NOT EXISTS ""Date"" DATE;

    -- Добавляем колонку Date в таблицу Turbins если её нет
    ALTER TABLE ""Turbins"" ADD COLUMN IF NOT EXISTS ""Date"" DATE;

    -- Создаём уникальный индекс для UPSERT в Boilers
    CREATE UNIQUE INDEX IF NOT EXISTS idx_boilers_unique ON ""Boilers""(""BoilerID"", ""StationID"", ""PeriodType"", ""Date"") WHERE ""Date"" IS NOT NULL;

    -- Создаём уникальный индекс для UPSERT в Turbins
    CREATE UNIQUE INDEX IF NOT EXISTS idx_turbins_unique ON ""Turbins""(""TurbinID"", ""StationID"", ""PeriodType"", ""Date"") WHERE ""Date"" IS NOT NULL;
    ";

    // ============ СТАРЫЕ ЗАПРОСЫ (для обратной совместимости) ============
    public static string truncate_week_TA = @"DELETE FROM ""Turbins"" WHERE ""Date"" IS NULL;";
    public static string truncate_week_KA = @"DELETE FROM ""Boilers"" WHERE ""Date"" IS NULL;";

    public static string insertQuerry_KA = @"
    INSERT INTO raw_boilers(BoilerID, stationID, KPD, production, date, consumption, hours, temp_fact, temp_nominal, temp_koef, humidity, ash)
    VALUES(@BoilerID, @StationID, @KPD, @Production, @Date, @Consumption, @Hours, @Temp_fact, @Temp_nominal, @Temp_koef, @Humidity, @Ash)
    ON CONFLICT (BoilerID, stationID, date) DO NOTHING;";

    public static string insertQuerry_TA = @"
    INSERT INTO raw_turbins(TurbinID, stationID, URT, consumption, date, hours, variation, nominal_urt)
    VALUES(@TurbinID, @StationID, @URT, @Consumption, @Date, @Hours, @Variation, @NominalURT)
    ON CONFLICT (TurbinID, stationID, date) DO NOTHING;";

    public static string insertQuerry_week_KA = @"
    INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"",""PeriodType"",""PeriodValue"")
    VALUES (@BoilerID, @StationID, @KPD, @Production, @Consumption, @PeriodType, @PeriodValue);";

    public static string insertQuerry_week_TA = @"
    INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"",""PeriodType"",""PeriodValue"", ""NominalURT"")
    VALUES(@TurbinID, @StationID, @URT, @Consumption, @PeriodType, @PeriodValue, @NominalURT);";

    public static string createTableQuery = @"
    CREATE TABLE IF NOT EXISTS Boilers (
        ID SERIAL PRIMARY KEY,
        BoilerID VARCHAR(10) NOT NULL,
        stationID SMALLINT,
        KPD NUMERIC(3, 3),
        value NUMERIC(10, 3),
        Date TIMESTAMP
    );";
}