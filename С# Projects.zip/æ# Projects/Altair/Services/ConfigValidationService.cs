using ClosedXML.Excel;

namespace Altair.Services
{
    public interface IConfigValidationService
    {
        ConfigValidationResult ValidateConfigFile(string filePath);
    }

    public class ConfigValidationResult
    {
        public bool IsValid { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
    }

    public class ConfigValidationService : IConfigValidationService
    {
        private readonly ILogger<ConfigValidationService> _logger;

        public ConfigValidationService(ILogger<ConfigValidationService> logger)
        {
            _logger = logger;
        }

        public ConfigValidationResult ValidateConfigFile(string filePath)
        {
            try
            {
                using (var workbook = new XLWorkbook(filePath))
                {
                    // Проверяем, что файл содержит хотя бы один лист
                    if (workbook.Worksheets.Count == 0)
                    {
                        return new ConfigValidationResult
                        {
                            IsValid = false,
                            ErrorMessage = "Файл не содержит листов"
                        };
                    }

                    int validSheets = 0;
                    bool hasBoilers = false;
                    bool hasTurbines = false;

                    foreach (var worksheet in workbook.Worksheets)
                    {
                        // Пропускаем лист инструкции
                        if (worksheet.Name == "Инструкция")
                            continue;

                        // Проверяем формат названия листа (первые 2 символа должны быть числом)
                        string sheetName = worksheet.Name;
                        if (sheetName.Length < 2)
                            continue;

                        if (!int.TryParse(sheetName.Substring(0, 2), out int stationCode))
                            continue;

                        // Проверяем структуру листа
                        var sheetValidation = ValidateWorksheet(worksheet);
                        if (sheetValidation.hasBoilers || sheetValidation.hasTurbines)
                        {
                            validSheets++;
                            hasBoilers = hasBoilers || sheetValidation.hasBoilers;
                            hasTurbines = hasTurbines || sheetValidation.hasTurbines;
                        }
                    }

                    if (validSheets == 0)
                    {
                        return new ConfigValidationResult
                        {
                            IsValid = false,
                            ErrorMessage = "Файл не содержит корректных листов с данными станций. Убедитесь, что названия листов начинаются с двузначного кода станции (например, '01...', '25...')"
                        };
                    }

                    if (!hasBoilers && !hasTurbines)
                    {
                        return new ConfigValidationResult
                        {
                            IsValid = false,
                            ErrorMessage = "Файл не содержит секций 'КОТЛЫ' или 'ТУРБИНЫ' ни на одном листе"
                        };
                    }

                    _logger.LogInformation($"Валидация прошла успешно. Найдено {validSheets} корректных листов.");

                    return new ConfigValidationResult
                    {
                        IsValid = true,
                        ErrorMessage = string.Empty
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при валидации конфигурационного файла");
                return new ConfigValidationResult
                {
                    IsValid = false,
                    ErrorMessage = $"Ошибка при чтении файла: {ex.Message}. Убедитесь, что файл является корректным Excel файлом формата .xlsx"
                };
            }
        }

        private (bool hasBoilers, bool hasTurbines) ValidateWorksheet(IXLWorksheet worksheet)
        {
            bool hasBoilers = false;
            bool hasTurbines = false;

            int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;

            for (int row = 1; row <= lastRow; row++)
            {
                var cell = worksheet.Cell(row, 1);
                if (cell == null || cell.IsEmpty())
                    continue;

                string cellValue = cell.Value.ToString()?.Trim() ?? "";

                if (cellValue == "КОТЛЫ")
                {
                    hasBoilers = true;
                }
                else if (cellValue == "ТУРБИНЫ")
                {
                    hasTurbines = true;
                }
            }

            return (hasBoilers, hasTurbines);
        }
    }
}
