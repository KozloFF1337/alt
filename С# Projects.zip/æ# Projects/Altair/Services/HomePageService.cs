using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

namespace Altair.Services
{
    public class HomePageService : IHomePageService
    {
        private readonly IHomePageRepository _repository;
        public HomePageService(IHomePageRepository repository)
        {
            _repository = repository;
        }
        public async Task<List<HomePage>> GetHomePages()
        {
            return await _repository.Get();
        }
    }
}
