namespace Altair.Models
{
    public enum PeriodType
    {
        Day = 0,    // День (раньше был Week)
        Month = 1,  // Месяц
        Year = 2    // Год
    }
}
