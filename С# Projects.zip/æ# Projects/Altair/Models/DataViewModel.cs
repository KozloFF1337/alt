
using System.Collections.Generic;
using Altair.Models;

namespace Altair.Models
{
	// Старый DataViewModel для совместимости со старыми View
	public class DataViewModel
	{
	public List<Boiler>? Boilers { get; set; }
	public List<Turbin>? Turbins { get; set; }
	public HomePage? HomePage { get; set; }
		// Можно добавить дополнительные свойства по необходимости
	}
}
