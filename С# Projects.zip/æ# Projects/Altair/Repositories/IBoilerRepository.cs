using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public interface IBoilerRepository
{
    Task<List<Boiler>> GetBoilers(PeriodType periodType);
    Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date);
    Task<List<DateTime>> GetAvailableDates(PeriodType periodType);
}
