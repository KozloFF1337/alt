using Altair;
using Microsoft.EntityFrameworkCore;
using Altair.Models;
using Microsoft.Data.SqlClient;
using Altair.Controllers;
using Microsoft.AspNetCore.Connections;
using Npgsql;
using Altair.Services;
using Altair.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Универсальные репозитории и сервисы
builder.Services.AddScoped<IBoilerRepository, BoilerRepository>();
builder.Services.AddScoped<ITurbinRepository, TurbinRepository>();
builder.Services.AddScoped<IHomePageRepository, HomePageRepository>();
builder.Services.AddScoped<IDataService, DataService>();
builder.Services.AddScoped<IHomePageService, HomePageService>();
builder.Services.AddScoped<IConfigValidationService, ConfigValidationService>();

// Singleton для отслеживания прогресса загрузки данных (общий для всех пользователей)
builder.Services.AddSingleton<IDataLoadProgressService, DataLoadProgressService>();

// DBLoadService зависит от DataLoadProgressService, поэтому регистрируем его после
builder.Services.AddScoped<IDBLoadService, DBLoadService>();

// Автозагрузка данных при старте приложения
builder.Services.AddHostedService<AutoLoadDataService>();

builder.Services.AddDbContext<BoilerDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<TurbinDbContext>(options => 
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<HomePageDBContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
var app = builder.Build();

// Инициализируем конфигурационные сервисы с правильным путём к файлам
// Используем ContentRootPath для определения корневой папки проекта
string contentRoot = app.Environment.ContentRootPath;

// Инициализируем Akscodes - загружает коды оборудования из Excel
Akscodes.Initialize(contentRoot);
Console.WriteLine($"[Akscodes] Загружено станций КА: {Akscodes.matching_dict_KA.Count}, ТА: {Akscodes.matching_dict_TA.Count}");

// Инициализируем NormativeValues - загружает нормативные значения КПД и УРТ из Excel
NormativeValues.Initialize(contentRoot);
Console.WriteLine($"[NormativeValues] Загружено станций КПД: {NormativeValues.KpdValues.Count}, УРТ: {NormativeValues.UrtValues.Count}");

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run("http://10.251.0.154:5000");